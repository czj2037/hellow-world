package com.yiibai.hello;
 
public interface HelloWorld {
	
	void printHelloWorld(String msg);
 
}