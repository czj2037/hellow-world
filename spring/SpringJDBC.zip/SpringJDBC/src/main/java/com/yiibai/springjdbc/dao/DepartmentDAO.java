package com.yiibai.springjdbc.dao;

import java.util.List;

import com.yiibai.springjdbc.bean.Department;

public interface DepartmentDAO {
   
   public List<Department> queryDepartment() throws Exception ;

}