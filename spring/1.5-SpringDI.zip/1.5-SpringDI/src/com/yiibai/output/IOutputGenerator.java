package com.yiibai.output;
 
public interface IOutputGenerator
{
	public void generateOutput();
}