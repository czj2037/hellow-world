package com.yiibai.output.impl;

import com.yiibai.output.IOutputGenerator;

public class CsvOutputGenerator implements IOutputGenerator {
	public void generateOutput() {
		System.out.println("This is Csv Output Generator");
	}
}