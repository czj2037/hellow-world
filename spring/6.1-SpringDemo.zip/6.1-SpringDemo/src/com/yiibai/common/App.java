package com.yiibai.common;

public class App 
{
    public static void main( String[] args )
    {
    	//...
    	
    }
}
