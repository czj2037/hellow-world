package com.yiibai.output.impl;
 
import com.yiibai.output.IOutputGenerator;
 
public class JsonOutputGenerator implements IOutputGenerator
{
	public void generateOutput(){
		System.out.println("This is Json Output Generator");
	}
}