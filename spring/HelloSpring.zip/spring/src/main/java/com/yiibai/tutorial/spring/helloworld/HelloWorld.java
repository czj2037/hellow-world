package com.yiibai.tutorial.spring.helloworld;

public interface HelloWorld {
	public void sayHello();
}
